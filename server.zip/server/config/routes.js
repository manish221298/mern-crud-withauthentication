const router = require("express").Router()
// const router = express.Router()

const userController = require("../app/controllers/employees")
const assessmentController = require("../app/controllers/assessment")

// api for users
router.post('/api/users', userController.create)
router.get("/api/users", userController.list)
router.put("/api/users/:id", userController.update)
router.delete("/api/users/:id",  userController.destroy)

// api for assessment
router.post('/api/assessment', assessmentController.create)
router.get("/api/assessment", assessmentController.list)
////////////////////



module.exports = router