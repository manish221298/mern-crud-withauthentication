const mongoose = require("mongoose")
const Schema = mongoose.Schema

const userSchema = new Schema ({
    roll: {
        type: String,
        required: [true, "Roll is required"],
        // unique: true
    },
    name: {
        type: String,
        required: [true, "Name is required field"]
    }
})

const User = mongoose.model('User', userSchema)
module.exports = User