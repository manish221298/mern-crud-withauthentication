const mongoose = require("mongoose")
const Schema = mongoose.Schema

const assessmentSchema = new Schema ({
    answer: {
        type: String,
        required: [true, "answer is required"],
        // unique: true
    }
})

const Assessment = mongoose.model('Assessment', assessmentSchema)
module.exports = Assessment