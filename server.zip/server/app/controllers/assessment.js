const Assessment = require("../models/assesment")
const assessmentController = {}

// create users
assessmentController.create = (req, res) => {
    const body = req.body
    
            const assessments = new Assessment(body)
                assessments.save()
                .then(user => {
                    res.json(user)
                })
                .catch(err => {
                    err.message = "network error"
                    res.json(err)
                })
                
        }

assessmentController.list = (req, res) => {
    Assessment.find()
    .then(assessment => {
        res.json(assessment)
    })
}

module.exports = assessmentController