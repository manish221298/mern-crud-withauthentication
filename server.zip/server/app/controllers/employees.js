const User = require("../models/employees")

const userController = {}

// create users
userController.create = (req, res) => {
    const body = req.body
    console.log("body", body)

    User.findOne({roll: body.roll})
    .then(rolls => {
        if(rolls){
            res.json({error: "Roll Number already exist"})
        }
        else{
            const users = new User(body)
                users.save()
                .then(user => {
                    console.log("user", user)
                    res.json(user)
                })
                .catch(err => {
                    err.message = "network error"
                    res.json(err)
                })
                    }
                })
        }

// show user list
userController.list = (req, res) => {
    const page = req.query.page < 1 ? 1 : req.query.page;
    const limit = req.query.limit < 1 ? 1 : req.query.limit;
     const search = req.query.search


    const startIndex = (page - 1) * limit
    const endIndex = page * limit

   User.find({$or:[
   {roll:{'$regex':search}},
   {name:{'$regex':search, $options: '$i'}}
    ]})
   .then((user) => {
   
    const data = {}
    const totalUser = user.length
    data.users = user.slice(startIndex, endIndex)
    data.counts = totalUser
    res.json(data)
   })
   .catch((err) => {
    res.json(err)
   })
}

// update user list

userController.update = (req, res) => {
    const id = req.params.id
    const body = req.body
    console.log(body)
    User.findByIdAndUpdate({_id: id}, body, {new: true})
    .then(user => {
        res.json(user)
    })
    .catch(err => {
        res.json(err)
    })
}

userController.destroy = (req, res) => {
    const id = req.params.id
    User.findByIdAndDelete(id)
    .then(user => {
        res.json(user)
    })
    .catch(err => {
        res.json(err)
    })
}

module.exports = userController