const express = require("express")
const app = express()
const cors = require("cors")
const configureDB = require("./config/database")
configureDB()
const router= express.router

const routes = require("./config/routes")

const port = 3055

app.use(cors())
app.use(express.json())
app.use("/", routes)

const employees = [
    {id:1, name: "manish"},
    {id:2, name: "lovejot"},
    {id:3, name: "bhavya"},
    {id:4, name: "vishal"}
]

app.get('/employees', (req, res) => {
    res.json(employees)
    console.log(employees)
})

app.listen(port, () => {
    console.log('Listening on port', port)
})

